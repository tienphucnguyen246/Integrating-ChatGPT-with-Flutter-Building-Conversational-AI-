String BASE_URL = "https://api.openai.com/v1";
String API_KEY =
    "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";
